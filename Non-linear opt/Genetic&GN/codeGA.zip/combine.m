function child = combine(parent1, parent2)
% Combines parameters in parent1 en parent2 into a new child.
% The function combine chooses randomly half of the parameters from parent1 
% complemented by the remaining parameters in parent2.

n_par        = size(parent1, 2);
n_parents    = size(parent1, 1);
T            = rand(n_parents, n_par) < 0.5;
child        = T .* parent1 + (1 - T).* parent2;
end    