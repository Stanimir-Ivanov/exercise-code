% Make matrix t and vector y available for all functions
global t
global y
load Student_Performance_Data_Set
t = [G1 G2];
y = G3;

%%% BELOW THIS LINE: perform Gauss-Newton by doing a linesearch with Newton
%%% directions and constant step length 1, using func_SSE, grad_SSE and hes_SSE.
%%% Store the result in a matrix "result", i.e. result = lineSearch(...)

