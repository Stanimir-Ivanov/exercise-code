function [ result ] = grad_SSE( x )
%GRAD_SSE Function that gives the gradient of func_SSE given parameters x.

% Make matrix t and vector y available in this function
global t
global y

%%% Calculate gradient of func_SSE here

end

